This is an optional mod_overrides file for VTC6.
It removes the checkbox from the pre-heist screen, because the "READY" text has already been replaced with a checkbox.
If two checkboxes sounds like it'll annoy you, then extract this. Otherwise you don't really need it.